'''Boomy2Hambuild Converte projetos Do Formato Boomy Para O Hambuild com eficiencia'''
import sys
import json
import os
import re
import random
from tkinter import Tk, filedialog
from pathlib import Path

print("Boomy2Hambuild Tool By SquareJDCBR")

OUTPUT_DIR = "output"
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

def choose_file(prompt: str) -> str:
    """Abre diálogo para selecionar arquivo"""
    root = Tk()
    root.withdraw()
    return filedialog.askopenfilename(title=prompt)

def parse_hamproj(content: str) -> dict:
    """Parseia arquivo .hamproj e extrai informações completas"""
    data = {}
    
    # Extrair metadata completa (name, artist, bpm, album, genre, etc)
    name_match = re.search(r'\(name "([^"]*)"\)', content)
    artist_match = re.search(r'\(artist "([^"]*)"\)', content)
    album_match = re.search(r'\(album_name "([^"]*)"\)', content)
    genre_match = re.search(r'\(genre (\w+)\)', content)
    year_match = re.search(r'\(year_released (\d+)\)', content)
    bpm_match = re.search(r'\(bpm (\d+)\)', content)
    char_match = re.search(r'\(default_character (\w+)\)', content)
    char_alt_match = re.search(r'\(default_character_alt (\w+)\)', content)
    venue_match = re.search(r'\(default_venue (\w+)\)', content)
    backup_char_match = re.search(r'\(backup_character (\w+)\)', content)
    backup_char_alt_match = re.search(r'\(backup_character_alt (\w+)\)', content)
    backup_venue_match = re.search(r'\(backup_venue (\w+)\)', content)
    
    data['name'] = name_match.group(1) if name_match else "Unknown"
    data['artist'] = artist_match.group(1) if artist_match else "Unknown"
    data['album_name'] = album_match.group(1) if album_match else "Album"
    data['genre'] = genre_match.group(1) if genre_match else "pop"
    data['year_released'] = int(year_match.group(1)) if year_match else 2024
    data['bpm'] = int(bpm_match.group(1)) if bpm_match else 100
    data['character'] = char_match.group(1) if char_match else "character"
    data['character_alt'] = char_alt_match.group(1) if char_alt_match else data['character']
    data['venue'] = venue_match.group(1) if venue_match else "venue"
    data['backup_character'] = backup_char_match.group(1) if backup_char_match else data['character']
    data['backup_character_alt'] = backup_char_alt_match.group(1) if backup_char_alt_match else data['character_alt']
    data['backup_venue'] = backup_venue_match.group(1) if backup_venue_match else data['venue']
    
    # Extrair moves da seção expert
    expert_match = re.search(r'\(expert\s*(.*?)\)', content, re.DOTALL)
    moves = []
    
    if expert_match:
        expert_content = expert_match.group(1)
        # Encontrar todos os items entre parênteses
        move_matches = re.findall(r'\(([^()]+)\)', expert_content)
        for move_item in move_matches:
            move_item = move_item.strip()
            if move_item and not move_item.startswith('section') and not move_item.startswith('perform'):
                moves.append(move_item)
    
    data['moves'] = moves
    return data

def build_full_move_name(move_obj: dict) -> str:
    """Constrói o nome completo do movimento incluindo a música
    Ex: rest_v1001 + forgetyou = rest_forgetyou_v1001"""
    move_name = move_obj.get('move', 'unknown')
    move_song = move_obj.get('move_song', '')
    
    if move_song:
        # Extrair versão do movimento (ex: v1001, v0)
        version_match = re.search(r'(_v\d+)$', move_name)
        if version_match:
            version = version_match.group(1)
            base_move = move_name.replace(version, '')
            return f"{base_move}_{move_song}{version}"
    
    return move_name

def extract_move_and_song(full_move_name: str) -> tuple:
    """Extrai move e move_song de um nome de movimento completo
    Ex: rest_forgetyou_v1001 → ('rest_v1001', 'forgetyou')
        double_shoulder_downonme_v0 → ('double_shoulder_v0', 'downonme')
    """
    # Remove a versão do final
    version_match = re.search(r'(_v\d+)$', full_move_name)
    if not version_match:
        # Não tem versão, retorna como está
        return full_move_name, ''
    
    version = version_match.group(1)
    base = full_move_name[:version_match.start()]  # Tudo antes da versão
    
    # O último underscore na base indica o início da música
    last_underscore = base.rfind('_')
    
    if last_underscore == -1:
        # Não tem underscore, não tem música separada
        return full_move_name, ''
    
    move_base = base[:last_underscore]
    move_song = base[last_underscore + 1:]
    
    return f"{move_base}{version}", move_song

def boomy_to_hambuild(json_path: str, output_path: str) -> None:
    """Converte arquivo Boomy JSON para Hambuild .hamproj - APENAS DIFICULDADE EXPERT"""
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            boomy_data = json.load(f)
        
        # Extrair metadata completa
        meta = boomy_data.get('meta', {})
        name = meta.get('name', 'Unknown')
        artist = meta.get('artist', 'Unknown')
        album_name = meta.get('album_name', 'Album')
        genre = meta.get('genre', 'pop')
        year_released = meta.get('year_released', 2024)
        bpm = meta.get('bpm', 100)
        default_character = meta.get('default_character', 'character')
        default_character_alt = meta.get('default_character_alt', default_character)
        default_venue = meta.get('default_venue', 'venue')
        backup_character = meta.get('backup_character', default_character)
        backup_character_alt = meta.get('backup_character_alt', default_character_alt)
        backup_venue = meta.get('backup_venue', default_venue)
        
        song_name_clean = name.lower().replace(' ', '')
        
        # Construir arquivo hambuild APENAS COM EXPERT
        hambuild_content = f'''(name "{name}")
(artist "{artist}")
(album_name "{album_name}")
(genre {genre})
(year_released {year_released})
(bpm {bpm})
(default_character {default_character})
(default_character_alt {default_character_alt})
(default_venue {default_venue})
(backup_character {backup_character})
(backup_character_alt {backup_character_alt})
(backup_venue {backup_venue})

(album_art "{song_name_clean}.jpg")
(audio "{song_name_clean}.wav")

(events
   (40.1 preview)
)

(expert
   (section_intro)
'''
        
        # Processar apenas dificuldade EXPERT
        timeline = boomy_data.get('timeline', {})
        
        if 'expert' in timeline:
            expert_data = timeline['expert']
            moves = expert_data.get('moves', [])
            
            # Adicionar movimentos com nomes completos incluindo a música
            for move in moves:
                full_move_name = build_full_move_name(move)
                hambuild_content += f"   ({full_move_name})\n"
            
            hambuild_content += "   (perform_end)\n"
        
        hambuild_content += ")\n"
        
        # Salvar arquivo
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(hambuild_content)
        
        print(f"✓ Conversão concluída (APENAS EXPERT): {output_path}")
        return True
    except Exception as e:
        print(f"✗ Erro ao converter: {e}")
        return False

def hambuild_to_boomy(hamproj_path: str, output_path: str) -> None:
    """Converte arquivo Hambuild .hamproj para Boomy JSON - Analisa corretamente"""
    try:
        with open(hamproj_path, 'r', encoding='utf-8') as f:
            hamproj_content = f.read()
        
        # Parsear arquivo hamproj
        parsed_data = parse_hamproj(hamproj_content)
        
        song_name_clean = parsed_data['name'].lower().replace(' ', '')
        
        # Estrutura básica Boomy - APENAS EXPERT
        boomy_data = {
            'move_lib': '',
            'timeline': {
                'expert': {
                    'moves': [],
                    'cameras': [
                        {'beat': 0, 'position': 'VENUE'}
                    ]
                }
            },
            'practice': {'expert': []},
            'moveLibrary': {},
            'supereasy': [],
            'drums': [],
            'partyJumps': [],
            'battleSteps': [],
            'partyBattleSteps': [],
            'bamPhrases': [],
            'events': [
                {'type': 'music_start', 'beat': 0},
                {'type': 'freestyle', 'beat': 192},
                {'type': 'music_end', 'beat': 374},
                {'type': 'end', 'beat': 375}
            ],
            'tempoChanges': [{'measure': 0, 'bpm': parsed_data['bpm']}],
            'meta': {
                'name': parsed_data['name'],
                'artist': parsed_data['artist'],
                'album_name': parsed_data['album_name'],
                'genre': parsed_data['genre'],
                'year_released': parsed_data['year_released'],
                'bpm': parsed_data['bpm'],
                'songid': random.randint(1000000000, 9999999999),
                'game_origin': 'custom',
                'default_character': parsed_data['character'],
                'default_character_alt': parsed_data['character_alt'],
                'default_venue': parsed_data['venue'],
                'backup_character': parsed_data['backup_character'],
                'backup_character_alt': parsed_data['backup_character_alt'],
                'backup_venue': parsed_data['backup_venue'],
                'rank': 1
            },
            'moveLibRev': 'mlib2',
            'cleanDrums': []
        }
        
        # Adicionar movimentos processados
        measure = 1
        for full_move_name in parsed_data['moves']:
            if full_move_name.strip():
                # Extrair move e move_song do nome completo
                move, move_song = extract_move_and_song(full_move_name)
                
                # Se não conseguir extrair a música do nome, usa o nome da música do projeto
                if not move_song:
                    move_song = song_name_clean
                    move = full_move_name
                
                move_obj = {
                    'measure': measure,
                    'clip': f'{full_move_name}_clip',
                    'move_origin': 'custom',
                    'move_song': move_song,
                    'move': move
                }
                boomy_data['timeline']['expert']['moves'].append(move_obj)
                measure += 1
        
        # Salvar arquivo
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(boomy_data, f, indent=2, ensure_ascii=False)
        
        print(f"✓ Conversão concluída (APENAS EXPERT): {output_path}")
        return True
    except Exception as e:
        print(f"✗ Erro ao converter: {e}")
        return False

def main():
    print("\n=== Boomy2Hambuild - Converter Boomy → Hambuild ===\n")
    
    json_path = choose_file("Selecione o arquivo .json (Boomy)")
    
    if json_path:
        filename = Path(json_path).stem
        output_file = os.path.join(OUTPUT_DIR, f"{filename}.hamproj")
        
        if boomy_to_hambuild(json_path, output_file):
            print(f"\n✓ Arquivo salvo em: {output_file}")
        else:
            print("\n✗ Conversão falhou!")
    else:
        print("\n✗ Nenhum arquivo selecionado!")

if __name__ == "__main__":
    main()



    
    